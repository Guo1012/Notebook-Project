# @lumen/notebook

独立的 Svelte 5 `.ipynb` 渲染组件。它只负责 Notebook 展示，不包含 Agent、聊天、JupyterHub、Kernel 或调度功能。

## 内部层级

```text
@lumen/notebook
└── notebook/        NotebookRenderer：组合整个 ipynb
    └── cells/       Code、Markdown、Raw、Circuit Cell
        └── outputarea/  stream、error 和富媒体输出列表
            └── rendermime/   MIME 选择、安全清理和渲染
                └── nbformat/  ipynb 类型、解析和标准化
```

这些层全部由 Lumen 自己实现。顶层 `notebook` 不依赖任何 `@jupyterlab/*` 或 Agent 模块。

每一层也提供稳定的子路径导出：

```ts
import { NotebookRenderer } from '@lumen/notebook/notebook';
import { CodeCell, CircuitCell } from '@lumen/notebook/cells';
import { OutputArea } from '@lumen/notebook/outputarea';
import { RenderMimeRegistry } from '@lumen/notebook/rendermime';
import { parseNotebook } from '@lumen/notebook/nbformat';
```

## 安装

```bash
npm install @lumen/notebook
```

在正式发布到 npm 前，可以安装本地打包文件：

```bash
npm install ./lumen-notebook-0.1.0.tgz
```

## 使用

```svelte
<script lang="ts">
  import { NotebookRenderer } from '@lumen/notebook';
  import notebook from './demo.ipynb?raw';
</script>

<NotebookRenderer {notebook} />
```

也可以传入解析后的 nbformat v4 对象：

```svelte
<NotebookRenderer notebook={ipynbJson} trusted={false} showCellToolbar={true} />
```

`trusted` 默认为 `false`，HTML、SVG 和 Markdown 会经过 DOMPurify 清理。Lumen Circuit Cell 使用合法的 code cell 存储，并通过 `metadata.lumen.cell_type = "circuit"` 识别。

## 导出

- `NotebookRenderer`：完整 `.ipynb` 渲染器
- `CellRenderer`：单个 Cell 渲染器
- `OutputRenderer`：Jupyter 输出渲染器
- `OutputArea`：一个 Cell 的完整输出区域
- `RenderMime`、`RenderMimeRegistry`：MIME 渲染与扩展注册
- `CodeCell`、`MarkdownCell`、`RawCell`、`CircuitCell`：独立 Cell 组件
- `parseNotebook`：Notebook 字符串/对象标准化
- nbformat 与 Circuit TypeScript 类型
