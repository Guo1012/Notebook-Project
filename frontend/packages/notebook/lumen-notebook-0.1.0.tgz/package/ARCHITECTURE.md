# @lumen/notebook architecture

依赖只能从上向下，不允许底层模块导入上层模块：

```text
notebook -> cells -> outputarea -> rendermime -> nbformat
```

| 层 | 职责 | 禁止依赖 |
| --- | --- | --- |
| `notebook/` | 接收并组合完整 `.ipynb` | Agent、Kernel、路由、存储 |
| `cells/` | Code、Markdown、Raw、Circuit 的视觉组件 | 页面状态、JupyterHub |
| `outputarea/` | 遍历 Cell outputs，处理 stream/error | Notebook 页面 |
| `rendermime/` | 选择 MIME renderer，清理 HTML/SVG/Markdown | Cell 与 Notebook |
| `nbformat/` | 类型、JSON 解析、source 标准化、Circuit metadata | 所有 Svelte UI |

Circuit 在标准 `.ipynb` 中仍存储为 `code` Cell，通过下面的扩展元数据恢复：

```json
{
  "metadata": {
    "lumen": {
      "cell_type": "circuit",
      "circuit": { "version": 1, "wires": 2, "gates": [] }
    }
  }
}
```
